<?php

namespace Fully\Repositories\Faq;

use Fully\Repositories\RepositoryInterface;

/**
 * Interface FaqInterface.
 *
 * @author Sefa Karagöz <karagozsefa@gmail.com>
 */
interface FaqInterface extends RepositoryInterface
{
}
