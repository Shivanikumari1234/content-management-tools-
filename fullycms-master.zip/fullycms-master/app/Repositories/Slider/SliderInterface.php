<?php

namespace Fully\Repositories\Slider;

/**
 * Interface SliderInterface.
 *
 * @author Sefa Karagöz <karagozsefa@gmail.com>
 */
interface SliderInterface
{
    /**
     * Get al data.
     *
     * @return mixed
     */
    public function all();
}
