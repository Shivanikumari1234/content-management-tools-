<?php

namespace Fully\Repositories\Menu;

/**
 * Interface MenuInterface.
 *
 * @author Sefa Karagöz <karagozsefa@gmail.com>
 */
interface MenuInterface
{
    /**
     * Get al data.
     *
     * @return mixed
     */
    public function all();
}
