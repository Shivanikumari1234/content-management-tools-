<?php

namespace Fully\Repositories\Tag;

use Fully\Repositories\RepositoryInterface;

/**
 * Interface TagInterface.
 *
 * @author Sefa Karagöz <karagozsefa@gmail.com>
 */
interface TagInterface extends RepositoryInterface
{
}
