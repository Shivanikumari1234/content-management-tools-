<?php

namespace Fully\Repositories\Category;

use Fully\Repositories\RepositoryInterface;

/**
 * Interface CategoryInterface.
 *
 * @author Sefa Karagöz <karagozsefa@gmail.com>
 */
interface CategoryInterface extends RepositoryInterface
{
}
