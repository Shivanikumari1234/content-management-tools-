<?php

namespace Fully\Events;

abstract class Event
{
    //
}
