<?php

namespace Fully\Models;

use Cartalyst\Sentinel\Users\EloquentUser;

/**
 * Class User.
 *
 * @author Sefa Karagöz <karagozsefa@gmail.com>
 */
class User extends EloquentUser
{
}
