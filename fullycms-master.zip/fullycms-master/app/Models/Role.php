<?php

namespace Fully\Models;

use Cartalyst\Sentinel\Roles\EloquentRole;

/**
 * Class Role.
 *
 * @author Sefa Karagöz <karagozsefa@gmail.com>
 */
class Role extends EloquentRole
{
}
