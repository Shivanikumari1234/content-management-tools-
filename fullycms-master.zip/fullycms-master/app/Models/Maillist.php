<?php

namespace Fully\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * Class Maillist.
 *
 * @author Sefa Karagöz <karagozsefa@gmail.com>
 */
class Maillist extends Model
{
    public $table = 'maillist';
}
